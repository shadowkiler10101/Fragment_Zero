import pygame
import math
import random
import asyncio  # Required for Web

# --- Configuration ---
WIDTH, HEIGHT = 1000, 700
FPS = 60
BLACK = (5, 5, 10)
WHITE = (255, 255, 255)
RED = (255, 60, 60)
CYAN = (0, 255, 255)
GRAY = (50, 50, 50)
GREEN = (0, 255, 100)
YELLOW = (255, 255, 0)

# Initialize globals
game_msg = ""
msg_timer = 0

# --- Helper Functions & Classes (Keep exactly as you had them) ---
def notify(text):
    global game_msg, msg_timer
    game_msg = text
    msg_timer = 90

class Loot(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()
        self.type = random.choice(["AMMO", "SHARD"])
        self.image = pygame.Surface((12, 12))
        self.image.fill(YELLOW if self.type == "AMMO" else CYAN)
        self.rect = self.image.get_rect(center=pos)

class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, angle, speed, damage, color):
        super().__init__()
        size = (12, 4) if speed > 15 else (6, 6)
        self.image = pygame.Surface(size)
        self.image.fill(color)
        self.image = pygame.transform.rotate(self.image, -math.degrees(angle))
        self.rect = self.image.get_rect(center=(x, y))
        self.dx = math.cos(angle) * speed
        self.dy = math.sin(angle) * speed
        self.damage = damage

    def update(self, obstacles):
        self.rect.x += self.dx
        self.rect.y += self.dy
        if pygame.sprite.spritecollideany(self, obstacles) or self.rect.x < 0 or self.rect.x > WIDTH or self.rect.y < 0 or self.rect.y > HEIGHT:
            self.kill()

class Obstacle(pygame.sprite.Sprite):
    def __init__(self, x, y, w, h):
        super().__init__()
        self.image = pygame.Surface((w, h))
        self.image.fill(GRAY)
        pygame.draw.rect(self.image, CYAN, (0,0,w,h), 1)
        self.rect = self.image.get_rect(topleft=(x, y))

class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((30, 30))
        self.image.fill(RED)
        self.rect = self.image.get_rect(center=(random.randint(100, WIDTH-100), random.randint(100, HEIGHT-100)))
        self.health = 30
        self.speed = 2
        self.state = "WANDER"
        self.wander_timer = 0
        self.dir = [random.uniform(-1, 1), random.uniform(-1, 1)]

    def has_line_of_sight(self, target_pos, obstacles):
        start = self.rect.center
        end = target_pos
        for wall in obstacles:
            if wall.rect.clipline(start, end): return False
        return True

    def update(self, player_pos, obstacles):
        dist = math.hypot(player_pos[0]-self.rect.centerx, player_pos[1]-self.rect.centery)
        old_x, old_y = self.rect.x, self.rect.y
        if 45 < dist < 400 and self.has_line_of_sight(player_pos, obstacles):
            self.state = "ATTACK"
            dx, dy = player_pos[0] - self.rect.centerx, player_pos[1] - self.rect.centery
            self.rect.x += (dx/dist) * self.speed
            self.rect.y += (dy/dist) * self.speed
        else:
            self.state = "WANDER"
            self.wander_timer -= 1
            if self.wander_timer <= 0:
                self.dir = [random.uniform(-1, 1), random.uniform(-1, 1)]
                self.wander_timer = 60
            self.rect.x += self.dir[0] * self.speed
            self.rect.y += self.dir[1] * self.speed
        for wall in obstacles:
            if self.rect.colliderect(wall.rect):
                self.rect.x, self.rect.y = old_x, old_y
                self.dir = [random.uniform(-1, 1), random.uniform(-1, 1)]

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((35, 35))
        self.image.fill(WHITE)
        self.rect = self.image.get_rect(center=(100, 100))
        self.hp = 100
        self.mode = "SNIPER"
        self.energy = 0
        self.ammo = 50

    def move(self, keys, obstacles):
        old_pos = self.rect.copy()
        if keys[pygame.K_w]: self.rect.y -= 5
        if keys[pygame.K_s]: self.rect.y += 5
        for wall in obstacles:
            if self.rect.colliderect(wall.rect): self.rect.y = old_pos.y
        if keys[pygame.K_a]: self.rect.x -= 5
        if keys[pygame.K_d]: self.rect.x += 5
        for wall in obstacles:
            if self.rect.colliderect(wall.rect): self.rect.x = old_pos.x

# --- Logic Globals ---
player = None
obstacles = None
enemies = None
bullets = None
loot_group = None
paused = False
state = "MENU"

def reset_game():
    global player, obstacles, enemies, bullets, loot_group, paused, game_msg, msg_timer
    player = Player()
    obstacles = pygame.sprite.Group()
    enemies = pygame.sprite.Group()
    bullets = pygame.sprite.Group()
    loot_group = pygame.sprite.Group()
    game_msg = ""
    msg_timer = 0
    obstacles.add(Obstacle(-200, 0, 200, HEIGHT), Obstacle(WIDTH, 0, 200, HEIGHT), 
                  Obstacle(0, -200, WIDTH, 200), Obstacle(0, HEIGHT, WIDTH, 200))
    obstacles.add(Obstacle(200, 200, 100, 40), Obstacle(700, 500, 40, 150), Obstacle(450, 300, 100, 100))
    for _ in range(10):
        new_enemy = Enemy()
        while pygame.sprite.spritecollideany(new_enemy, obstacles):
            new_enemy.rect.center = (random.randint(100, WIDTH-100), random.randint(100, HEIGHT-100))
        enemies.add(new_enemy)
    paused = False

def draw_main_menu(screen, font):
    screen.fill(BLACK)
    title_txt = font.render("FRAGMENT ZERO", True, CYAN)
    screen.blit(title_txt, (WIDTH//2 - 100, 150))
    s_rect = pygame.Rect(WIDTH//2 - 125, 300, 250, 50)
    m_rect = pygame.Rect(WIDTH//2 - 125, 380, 250, 50)
    pygame.draw.rect(screen, GRAY, s_rect)
    pygame.draw.rect(screen, GRAY, m_rect)
    screen.blit(font.render("SINGLEPLAYER", True, WHITE), (s_rect.x + 45, s_rect.y + 12))
    screen.blit(font.render("MULTIPLAYER (WIP)", True, WHITE), (m_rect.x + 25, m_rect.y + 12))
    if msg_timer > 0:
        msg_surf = font.render(game_msg, True, YELLOW)
        screen.blit(msg_surf, (WIDTH//2 - msg_surf.get_width()//2, 500))
    return s_rect, m_rect

def draw_pause_menu(screen, font):
    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 200)) 
    screen.blit(overlay, (0,0))
    res_rect = pygame.Rect(WIDTH//2 - 100, HEIGHT//2 - 60, 200, 50)
    quit_rect = pygame.Rect(WIDTH//2 - 100, HEIGHT//2 + 10, 200, 50)
    pygame.draw.rect(screen, GRAY, res_rect)
    pygame.draw.rect(screen, RED, quit_rect)
    screen.blit(font.render("RESUME", True, WHITE), (res_rect.x + 65, res_rect.y + 12))
    screen.blit(font.render("QUIT", True, WHITE), (quit_rect.x + 75, quit_rect.y + 12))
    return res_rect, quit_rect

# --- Main Entry Point ---
async def main():
    global state, paused, running, msg_timer

    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    clock = pygame.time.Clock()
    font = pygame.font.SysFont("Consolas", 24)
    
    reset_game()
    running = True

    while running:
        keys = pygame.key.get_pressed()
        mouse_pos = pygame.mouse.get_pos()

        if msg_timer > 0:
            msg_timer -= 1

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if state == "MENU":
                if event.type == pygame.MOUSEBUTTONDOWN:
                    s_rect, m_rect = draw_main_menu(screen, font)
                    if s_rect.collidepoint(event.pos): 
                        reset_game() 
                        state = "PLAYING_SINGLE"
                    if m_rect.collidepoint(event.pos): 
                        notify("SERVER CONNECTION UNAVAILABLE (WIP)")

            elif state == "PLAYING_SINGLE":
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE: paused = not paused
                    if not paused and event.key == pygame.K_q:
                        player.mode = "SHOTGUN" if player.mode == "SNIPER" else "SNIPER"
                        notify(f"TACTICAL MODE: {player.mode}")

                if event.type == pygame.MOUSEBUTTONDOWN:
                    if not paused:
                        if event.button == 1 and player.ammo > 0:
                            angle = math.atan2(mouse_pos[1]-player.rect.centery, mouse_pos[0]-player.rect.centerx)
                            if player.mode == "SNIPER":
                                player.ammo -= 1
                                bullets.add(Bullet(player.rect.centerx, player.rect.centery, angle, 20, 50, CYAN))
                            else:
                                player.ammo -= 3
                                for i in range(-2, 3):
                                    bullets.add(Bullet(player.rect.centerx, player.rect.centery, angle+(i*0.2), 10, 15, RED))
                        elif event.button == 3:
                            for e in enemies:
                                if math.hypot(player.rect.centerx-e.rect.centerx, player.rect.centery-e.rect.centery) < 85:
                                    e.health -= 35
                                    notify("MELEE HIT REGISTERED")
                    else:
                        res_rect, quit_rect = draw_pause_menu(screen, font)
                        if res_rect.collidepoint(event.pos): paused = False
                        if quit_rect.collidepoint(event.pos): running = False

        # --- Logic & Drawing ---
        if state == "MENU":
            draw_main_menu(screen, font)
        elif state == "PLAYING_SINGLE":
            if not paused:
                player.move(keys, obstacles)
                enemies.update(player.rect.center, obstacles)
                bullets.update(obstacles)
                
                for b in bullets:
                    hits = pygame.sprite.spritecollide(b, enemies, False)
                    for e in hits:
                        e.health -= b.damage
                        b.kill()
                        if e.health <= 0:
                            loot_group.add(Loot(e.rect.center))
                            e.kill()

                picked_up = pygame.sprite.spritecollide(player, loot_group, True)
                for item in picked_up:
                    if item.type == "AMMO": 
                        player.ammo += 15
                        notify("+15 AMMO")
                    else: 
                        player.energy += 1
                        notify("+1 CORE SHARD")

                if pygame.sprite.spritecollide(player, enemies, False): player.hp -= 0.5
                
                if len(enemies) == 0:
                    screen.fill(BLACK)
                    screen.blit(font.render("AREA CLEARED - RETURNING TO MENU", True, GREEN), (WIDTH//2-200, HEIGHT//2))
                    pygame.display.flip()
                    await asyncio.sleep(2) # Non-blocking wait
                    state = "MENU"

                if player.hp <= 0:
                    screen.fill(BLACK)
                    screen.blit(font.render("GAME OVER - RETURNING TO MENU", True, RED), (WIDTH//2-200, HEIGHT//2))
                    pygame.display.flip()
                    await asyncio.sleep(2) # Non-blocking wait
                    state = "MENU"

                screen.fill(BLACK)
                obstacles.draw(screen)
                loot_group.draw(screen)
                bullets.draw(screen)
                enemies.draw(screen)
                screen.blit(player.image, player.rect)
                
                # HUD
                pygame.draw.rect(screen, RED, (20, 20, 200, 15))
                pygame.draw.rect(screen, GREEN, (20, 20, max(0, int(player.hp * 2)), 15))
                screen.blit(font.render(f"MODE: {player.mode} | AMMO: {player.ammo}", True, WHITE), (20, 45))
                screen.blit(font.render(f"SHARDS: {player.energy}", True, CYAN), (20, 75))
                
                if msg_timer > 0:
                    msg_surf = font.render(game_msg, True, YELLOW)
                    screen.blit(msg_surf, (WIDTH//2 - msg_surf.get_width()//2, HEIGHT - 60))
            else:
                draw_pause_menu(screen, font)

        pygame.display.flip()
        await asyncio.sleep(0) # This allows the browser to run
        clock.tick(FPS)

    pygame.quit()

# Run the game
asyncio.run(main())
